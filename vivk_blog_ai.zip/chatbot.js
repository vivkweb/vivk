
const DEMO_MODE = false;
const chatBtn = document.getElementById("chat-btn");
const chatBox = document.getElementById("chat-box");
const chatLog = document.getElementById("chat-log");
const chatInput = document.getElementById("chat-input");
const sendBtn = document.getElementById("send-btn");

chatBtn.addEventListener("click", () => chatBox.classList.toggle("hidden"));
sendBtn.addEventListener("click", send);
chatInput.addEventListener("keydown", (e)=>{ if(e.key==="Enter") send(); });

function pushMsg(role, text){
  const div = document.createElement("div");
  div.className = "msg " + (role==="user" ? "user" : "bot");
  div.textContent = (role==="user" ? "🧑‍💻 " : "🤖 ") + text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

async function send(){
  const text = chatInput.value.trim();
  if(!text) return;
  pushMsg("user", text);
  chatInput.value = "";
  pushMsg("bot", "جاري التفكير...");
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ messages: [{role:"system", content:"أنت مساعد عربي/إنجليزي مختصر ومفيد."}, {role:"user", content:text}] })
  });
  const data = await res.json().catch(()=>({error:"رد غير متوقع"}));
  chatLog.lastChild.remove();
  pushMsg("bot", data.reply || data.error || "حصل خطأ.");
}
